<body class="off-canvas-nav-left" style="padding-top:70px;">

<div class="container">

    <h1>Site Completion Percentage</h1>
    <div class="progress" style="width: 50%;">
        <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%">
            <span class="sr-only">25% Complete</span>
            25%
        </div>
    </div>

</div> <!-- /container -->


<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>