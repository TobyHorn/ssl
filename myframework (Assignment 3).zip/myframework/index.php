<?php

//App start
include './bin/config.php';

?>